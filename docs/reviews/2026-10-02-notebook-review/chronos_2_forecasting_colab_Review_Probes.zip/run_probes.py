"""Review probes for tutorials/chronos_2_forecasting_colab.ipynb (row 11, Notebook Review Framework v1).

Direct execution, local CPU, repository .venv (torch 2.11.0+cpu, NOT the notebook's torch==2.14.0 pin;
numpy 2.5.3, pandas 3.0.5, transformers 4.57.6, chronos-forecasting as locked). Install cell skipped via
DIMER_NOTEBOOK_CI_PREINSTALLED=1 (the notebook's own documented executor hook). The pinned
model.safetensors (sha256 ddcda3c7...) is hard-linked into a scratch work dir; README.md/config.json are
fetched by the notebook's own stage_missing_files from the Hub at the pinned revision.

Field changes are made the way an executor would (EXE6): the literal form line in a copy of the cell
source is replaced, then cells are re-run "from that cell" as the notebook instructs.

Usage: python run_probes.py <notebook.ipynb> <workdir> <model.safetensors> <results.json>
"""
from __future__ import annotations

import contextlib
import hashlib
import io
import json
import os
import sys
import time
import traceback
from pathlib import Path

NB, WORK, WEIGHT, OUT = (Path(a) for a in sys.argv[1:5])
os.environ["DIMER_NOTEBOOK_CI_PREINSTALLED"] = "1"
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
os.environ.pop("DIMER_BYOD_PATH", None)
os.environ.pop("DIMER_RUN_COVARIATE_DEMO", None)

nb = json.loads(NB.read_text(encoding="utf-8"))
cells = nb["cells"]
src = {i: "".join(c["source"]) for i, c in enumerate(cells)}
code_idx = [i for i, c in enumerate(cells) if c["cell_type"] == "code"]
results: dict = {"notebook": str(NB), "notebook_sha256": hashlib.sha256(NB.read_bytes()).hexdigest(), "probes": {}}


def save():
    OUT.write_text(json.dumps(results, indent=2, default=str), encoding="utf-8")


# ---------- static probes ----------
static = {}
static["metadata_dimer"] = nb["metadata"].get("dimer")
static["n_cells"] = len(cells)
static["n_code_cells"] = len(code_idx)
carried = [i for i in code_idx if cells[i].get("metadata", {}).get("dimer", {}).get("embedded_module")]
static["carried_cells"] = carried
static["carried_lines"] = sum(src[i].count("\n") + 1 for i in carried)
static["carried_cells_collapsed"] = [cells[i].get("metadata", {}).get("cellView") for i in carried]
static["any_title_infrastructure"] = any("Infrastructure" in src[i] for i in code_idx)
md = "\n".join(src[i] for i, c in enumerate(cells) if c["cell_type"] == "markdown")
lower = md.lower()
for key in ["how to use", "roadmap", "glossary", "predict", "check your", "troubleshoot", "expected result",
            "what to notice", "look for", "conclusion", "audience", "learner", "input →", "exercise", "workshop"]:
    static[f"md_has::{key}"] = lower.count(key)
static["opening_spec_line"] = [ln for ln in src[0].splitlines() if "specification" in ln.lower()]
static["interpretation_repeats_proves"] = src[36].count("proves") if len(cells) > 36 else None
results["probes"]["static"] = static
save()

# ---------- execution helpers ----------
WORK.mkdir(parents=True, exist_ok=True)
wdir = WORK / "weights" / "chronos-2"
wdir.mkdir(parents=True, exist_ok=True)
target = wdir / "model.safetensors"
if not target.exists():
    os.link(WEIGHT, target)
os.chdir(WORK)
ns: dict = {"__name__": "__main__"}


def run_cell(i: int, source: str | None = None) -> dict:
    code = source if source is not None else src[i]
    buf = io.StringIO()
    t0 = time.time()
    rec = {"cell": i}
    try:
        with contextlib.redirect_stdout(buf):
            exec(compile(code, f"cell-{i}", "exec"), ns, ns)
        rec["status"] = "ok"
    except BaseException as exc:  # noqa: BLE001
        rec["status"] = "error"
        rec["error_type"] = type(exc).__name__
        rec["error"] = str(exc)[:800]
        rec["error_code"] = getattr(exc, "code", None)
        rec["tb_tail"] = traceback.format_exc().splitlines()[-3:]
    rec["seconds"] = round(time.time() - t0, 2)
    rec["stdout_tail"] = buf.getvalue()[-1500:]
    return rec


def run_from(start: int, overrides: dict[int, str] | None = None, stop_on_error=True) -> list[dict]:
    out = []
    for i in code_idx:
        if i < start:
            continue
        rec = run_cell(i, (overrides or {}).get(i))
        out.append(rec)
        if rec["status"] != "ok" and stop_on_error:
            break
    return out


def with_field(i: int, line_prefix: str, new_line: str) -> str:
    lines = src[i].splitlines()
    hits = [k for k, ln in enumerate(lines) if ln.startswith(line_prefix)]
    assert len(hits) == 1, (line_prefix, hits)
    lines[hits[0]] = new_line
    return "\n".join(lines) + "\n"


def snapshot_metrics() -> dict:
    d = {}
    for name in ["evaluation", "last_value_evaluation"]:
        if name in ns:
            d[name] = ns[name].aggregate
    d["seasonal_metrics"] = ns.get("seasonal_metrics")
    if "report" in ns:
        d["report_verdict"] = ns["report"].get("verdict")
    if "result" in ns:
        d["effective_context_length"] = ns["result"].inference.get("effective_context_length")
        d["effective_prediction_length"] = ns["result"].inference.get("effective_prediction_length")
    if "input_manifest" in ns:
        d["manifest_findings"] = ns["input_manifest"].get("findings")
        d["manifest_verdict"] = ns["input_manifest"].get("verdict")
    return d


# ---------- P1 clean default ----------
t0 = time.time()
p1 = run_from(0)
results["probes"]["P1_default"] = {"cells": [{k: v for k, v in r.items() if k != "stdout_tail"} | {"stdout_tail": r["stdout_tail"][-400:]} for r in p1],
                                   "all_ok": all(r["status"] == "ok" for r in p1), "n_cells_run": len(p1),
                                   "wall_s": round(time.time() - t0, 1), "metrics": snapshot_metrics(),
                                   "outputs": sorted(os.listdir("outputs")) if Path("outputs").exists() else None}
if "pipe" in ns:
    results["probes"]["P1_default"]["device"] = str(getattr(ns["pipe"], "device", None))
    results["probes"]["P1_default"]["dtype"] = str(getattr(ns["pipe"], "dtype", None))
import torch  # noqa: E402
results["probes"]["P1_default"]["torch"] = torch.__version__
save()

# ---------- P2 PREDICTION_LENGTH changes (rerun from cell 21 as the Next-experiments text suggests) ----------
p2 = {}
for h in [24, 48, 72, 73, 93, 94, 1024]:
    cell21 = with_field(21, "PREDICTION_LENGTH =", f"PREDICTION_LENGTH = {h}  # @param {{type:\"integer\"}}")
    recs = run_from(21, {21: cell21})
    last = recs[-1]
    p2[str(h)] = {"all_ok": all(r["status"] == "ok" for r in recs), "failed_cell": None if last["status"] == "ok" else last["cell"],
                  "error": last.get("error"), "error_code": last.get("error_code"),
                  "metrics": snapshot_metrics() if last["status"] == "ok" else None}
results["probes"]["P2_prediction_length"] = p2
save()

# ---------- P3 BYOD via DIMER_BYOD_PATH ----------
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

byod_dir = WORK / "byod"
byod_dir.mkdir(exist_ok=True)


def hourly(sid, n, base, start="2026-02-01"):
    ts = pd.date_range(start, periods=n, freq="h")
    step = np.arange(n, dtype=float)
    rng = np.random.default_rng(7 + n)
    return pd.DataFrame({"series_id": sid, "timestamp": ts.strftime("%Y-%m-%dT%H:%M:%S"),
                         "target": base + 5 * np.sin(2 * np.pi * step / 24) + rng.normal(0, 1, n)})


cases: dict[str, bytes] = {}
good = pd.concat([hourly("north", 120, 50), hourly("south", 100, 80)], ignore_index=True)
good["temp_c"] = 25 + np.arange(len(good)) % 7
cases["valid_two_series_with_covariate"] = good.to_csv(index=False).encode()
daily = hourly("d", 60, 10)
daily["timestamp"] = pd.date_range("2025-01-01", periods=60, freq="D").strftime("%Y-%m-%d")
cases["valid_daily"] = daily.to_csv(index=False).encode()
cases["short_series_14_rows"] = hourly("s", 14, 10).to_csv(index=False).encode()
cases["short_hourly_30_rows"] = hourly("s", 30, 10).to_csv(index=False).encode()
cases["duplicate_header"] = b"series_id,timestamp,target,target\nA,2026-01-01T00:00:00,1,2\n"
renamed = hourly("r", 60, 10).rename(columns={"target": "value"})
cases["target_named_value"] = renamed.to_csv(index=False).encode()
cases["non_utf8_bytes"] = "series_id,timestamp,target\nA,2026-01-01T00:00:00,1\n".encode("utf-16")
gap = hourly("g", 60, 10).drop(index=[30, 31])
cases["gap_in_timestamps"] = gap.to_csv(index=False).encode()
nonnum = hourly("n", 60, 10)
nonnum["target"] = nonnum["target"].astype(object)
nonnum.loc[5, "target"] = "n/a"
cases["non_numeric_target"] = nonnum.to_csv(index=False).encode()
cases["bom_prefixed_valid"] = b"\xef\xbb\xbf" + hourly("b", 60, 10).to_csv(index=False).encode()
monthly = hourly("m", 40, 10)
monthly["timestamp"] = pd.date_range("2020-01-31", periods=40, freq="ME").strftime("%Y-%m-%d")
cases["monthly"] = monthly.to_csv(index=False).encode()
withaux = hourly("x", 60, 10)
withaux["target_aux"] = 1.0
cases["has_target_aux_column"] = withaux.to_csv(index=False).encode()

p3 = {}
for name, payload in cases.items():
    path = byod_dir / f"{name}.csv"
    path.write_bytes(payload)
    os.environ["DIMER_BYOD_PATH"] = str(path)
    recs = run_from(21)
    last = recs[-1]
    p3[name] = {"all_ok": all(r["status"] == "ok" for r in recs), "failed_cell": None if last["status"] == "ok" else last["cell"],
                "error_type": last.get("error_type"), "error": last.get("error"), "error_code": last.get("error_code"),
                "metrics": snapshot_metrics() if last["status"] == "ok" else None,
                "sample_kind": ns.get("sample_kind")}
    if last["status"] == "ok":
        p3[name]["plotted_series"] = str(ns.get("plot_series"))
        p3[name]["n_forecast_rows"] = len(ns["result"].forecast)
        p3[name]["forecast_timestamps_within_input"] = bool(
            pd.to_datetime(ns["result"].forecast["timestamp"]).max() <= pd.to_datetime(ns["frame"]["timestamp"]).max())
os.environ.pop("DIMER_BYOD_PATH", None)
results["probes"]["P3_byod"] = p3
save()

# ---------- P4 Mode D on, then P5 return to sample: stale export check ----------
run_from(21)  # back to sample defaults
cell35 = with_field(35, "RUN_COVARIATE_DEMO =", "RUN_COVARIATE_DEMO = True  # @param {type:\"boolean\"}")
rec = run_cell(35, cell35)
p4 = {"status": rec["status"], "error": rec.get("error"), "stdout_tail": rec["stdout_tail"][-600:]}
if rec["status"] == "ok":
    cr = ns["cov_result"]
    p4["known_future"] = cr.inference.get("known_future_covariate_names")
    p4["provenance_keys"] = sorted(cr.provenance.keys()) if isinstance(cr.provenance, dict) else None
    p4["provenance_mentions_known_future"] = "known_future" in json.dumps(cr.provenance, default=str)
    p4["exported_files_after"] = sorted(os.listdir("outputs"))
    p4["covariate_csv_columns"] = list(pd.read_csv("outputs/chronos_covariate_forecast.csv").columns)
    p4["result_json_mentions_covariate"] = "covariate" in Path("outputs/chronos_2_forecasting_result.json").read_text(encoding="utf-8")
    p4["provenance_json_mentions_known_future"] = "known_future" in Path("outputs/chronos_provenance.json").read_text(encoding="utf-8")
results["probes"]["P4_mode_d"] = p4
# P5: rerun defaults with Mode D off; covariate CSV from the previous run remains?
recs = run_from(21)
results["probes"]["P5_rerun_after_mode_d"] = {"all_ok": all(r["status"] == "ok" for r in recs),
                                               "stale_covariate_csv_present": Path("outputs/chronos_covariate_forecast.csv").exists(),
                                               "outputs": sorted(os.listdir("outputs"))}
save()
print("done", OUT)
