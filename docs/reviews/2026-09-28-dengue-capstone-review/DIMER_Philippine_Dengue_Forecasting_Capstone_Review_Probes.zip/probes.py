"""Review probes for PR20. Synthetic fixtures and model doubles, NOT health/model evidence.
Imports the exact modules extracted from the supplied notebook; never fetches data or weights.
"""
from __future__ import annotations
import ast,contextlib,copy,csv,hashlib,importlib.metadata,io,json,os,pathlib,shutil,subprocess,sys,tempfile,traceback,zipfile
import numpy as np
BASE=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'embedded'))
import dengue_core as core
import dengue_runtime as run
import dengue_models as models
OUT=BASE/'probe_outputs';OUT.mkdir(exist_ok=True)
RESULTS=[]
def save():
 (OUT/'results.json').write_text(json.dumps({'scope':'CPU review; synthetic series and model doubles only. Not Colab/GPU/model-performance evidence.','environment':{'python':sys.version,'numpy':np.__version__},'results':RESULTS},indent=2,allow_nan=False))
def probe(name):
 def wrap(f):
  try:
   result=f(); RESULTS.append({'name':name,'status':'completed','observations':result}); print(name,'COMPLETED',flush=True)
  except Exception as e:
   RESULTS.append({'name':name,'status':'probe_error','error':str(e),'traceback':traceback.format_exc()});print(name,'PROBE ERROR',repr(e),flush=True)
  save();return f
 return wrap

def rows(nyears=16,constant=None):
 return [dict(year=2010+i//52,block=1+i%52,cases=float(constant if constant is not None else 20+(i%52)+((i//52)%4)*3),rain=float(10+i%11),temp=float(24+i%7)) for i in range(52*nyears)]
def setup(name,series):
 root=OUT/name; root.mkdir(exist_ok=True)
 for p in (BASE/'embedded').iterdir():
  if p.is_file():shutil.copyfile(p,root/p.name)
 (root/'results').mkdir(exist_ok=True)
 path=root/'input.csv'
 with path.open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=['year','block','cases','rain','temp']);w.writeheader();w.writerows(series)
 run.write(root/'run_config.json',dict(byod_csv=str(path),source_blocks_confirmed=True))
 return root

def raised(f):
 try:f()
 except Exception as e:return {'type':type(e).__name__,'message':str(e)}
 return None

@probe('01_notebook_and_embedded_identity')
def p01():
 p=BASE/'input_notebook.ipynb';b=p.read_bytes();n=json.loads(b)
 import nbformat
 nbformat.validate(nbformat.reads(b.decode(),as_version=4))
 code=[c for c in n['cells'] if c['cell_type']=='code']
 for c in code:compile(''.join(c['source']),c['id'],'exec')
 source=json.loads((BASE/'embedded/source.json').read_text())
 for name,d in source['files'].items():assert hashlib.sha256((BASE/'embedded'/name).read_bytes()).hexdigest()==d
 return {'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'sha256':hashlib.sha256(b).hexdigest(),'cells':len(n['cells']),'code_cells':len(code),'outputs':sum(len(c.get('outputs',[])) for c in code),'bound_files':len(source['files'])}

@probe('02_availability_target_maturity_weather_pairing')
def p02():
 r=rows();out=[]
 for d in (0,2):
  for h in (1,2,3,4):
   for window in (52,104):
    a=core.training_task(r,727,h,window,d,False);b=core.training_task(r,727,h,window,d,True)
    assert np.array_equal(a['issuance_indices'],b['issuance_indices'])
    assert np.array_equal(a['target_indices'],b['target_indices'])
    assert np.array_equal(a['X'],b['X'][:,:len(a['feature_names'])]);assert np.array_equal(a['y'],b['y'])
    assert a['target_indices'].max()<=727-d
    poison=copy.deepcopy(r)
    for x in poison[728-d:]:x.update(cases=1e8,rain=2e8,temp=-1e8)
    z=core.training_task(poison,727,h,window,d,True)
    for k in ('X','y','query'):np.testing.assert_array_equal(z[k],b[k])
    out.append({'delay':d,'horizon':h,'window':window,'support_n':len(a['y']),'latest_target':int(a['target_indices'].max()),'cutoff':a['cutoff']})
 return {'checks':out,'poison_future_unchanged':True,'case_weather_same_rows_and_targets':True,'year_boundary':core.target_key(r,728)}

@probe('03_metrics_intervals_and_block_bootstrap')
def p03():
 m=core.metrics([0,2],[1,0]);assert m['mae']==1.5 and m['bias']==-.5
 assert core.skill(0,0) is None
 q=core.interval_metrics([0,10],[[0,0,2],[5,9,12]]);assert q['coverage_80']==1
 errors={'nonfinite_metric':raised(lambda:core.metrics([1],[np.nan])),'crossed_quantiles':raised(lambda:core.interval_metrics([1],[[2,1,3]]))}
 y=np.ones((26,4))*4;a=y+2;b=y+1;boot=core.paired_bootstrap(y,a,b)
 assert boot['difference_b_minus_a']==-1 and boot['ci95']==[-1.,-1.]
 raw,eff,clip=core.inverse_counts([-1,0,np.log1p(2.25)]);assert clip.tolist()==[True,False,False]
 return {'known_metrics':m,'intervals':q,'bootstrap':boot,'refusals':errors,'raw':raw.tolist(),'effective':eff.tolist()}

@probe('04_chronos_output_boundary_and_delay_alignment')
def p04():
 import torch
 class Model:
  def __init__(self,mode='ok'):self.mode=mode;self.calls=[]
  def predict_quantiles(self,history,**kwargs):
   self.calls.append((history,kwargs));h=kwargs['prediction_length'];q=torch.tensor([[[i,i+1,i+2] for i in range(h)]],dtype=torch.float32)
   if self.mode=='nan':q[0,0,0]=float('nan')
   if self.mode=='cross':q[0,0,:]=torch.tensor([4,2,1])
   if self.mode=='shape':q=q[0]
   return [q],None
 for mode in ('nan','cross','shape'):assert raised(lambda:models.chronos_predict(Model(mode),[1,2,3],4))
 m=Model();root=setup('delay_adapter',rows());oldload=models.load_chronos;oldfree=run.free_gpu
 models.load_chronos=lambda *a:m;run.free_gpu=lambda:None
 try:p,_=run.model_forecasts(root,rows(),[727],104,'chronos',delay=2)
 finally:models.load_chronos=oldload;run.free_gpu=oldfree
 assert [x['raw_prediction'] for x in p]==[3,4,5,6]
 assert m.calls[0][1]['prediction_length']==6 and m.calls[0][0][0][-1]==rows()[725]['cases']
 return {'delay':2,'effective_horizon':6,'selected_medians':[x['raw_prediction'] for x in p],'history_latest_index':725,'history_size':len(m.calls[0][0][0]),'bad_shape_nan_crossing_rejected':True}

@probe('05_constant_BYOD_accepted_before_Mitra_refusal')
def p05():
 r=rows(6,0);root=setup('constant_byod',r);run.prepare(root);run.baselines(root)
 p=run.read(root/'results/plan.json');task=core.training_task(r,p['validation'][0],1,52)
 err=raised(lambda:models.mitra_predict(None,task['X'],task['y'],task['query'][None]))
 assert err and err['type']=='ValueError' and 'nonconstant support' in err['message']
 return {'input_years':6,'all_cases':0,'prepare_succeeded':True,'baseline_metrics':run.read(root/'results/baseline_metrics.json'),'first_validation_support_n':len(task['y']),'actual_adapter_refusal_before_upstream_import':err}

@probe('06_BYOD_semantic_and_row_width_checks')
def p06():
 results={}
 for name,mutate in [('fractional_cases',lambda r:r[0].update(cases=.5)),('out_of_range_temperature',lambda r:r[0].update(temp=500)),('missing_cases',lambda r:r[0].update(cases=None)),('negative_cases',lambda r:r[0].update(cases=-1))]:
  r=rows(6);mutate(r);root=setup('byod_'+name,r);e=raised(lambda:run.prepare(root));results[name]=e or 'accepted'
 root=setup('byod_extra_row_field',rows(6));p=root/'input.csv';lines=p.read_text().splitlines();lines[1]+=',UNEXPECTED_EXTRA_FIELD';p.write_text('\n'.join(lines)+'\n');e=raised(lambda:run.prepare(root));results['extra_row_field']=e or 'accepted; extra unnamed field discarded'
 root=setup('byod_duplicate_header',rows(6));p=root/'input.csv';p.write_text(p.read_text().replace('year,block,cases,rain,temp','year,block,cases,rain,rain',1));results['duplicate_header']=raised(lambda:run.prepare(root))
 root=setup('byod_five_years',rows(5));results['five_years']=raised(lambda:run.prepare(root))
 return results

@probe('07_complete_cohort_integrity')
def p07():
 r=rows();origin=727;p=[run.prediction(r,s,origin,h,0,10,[9,10,11] if s=='chronos' else None) for s in run.SYSTEMS for h in range(1,5)];run.assert_cohort(p,[origin],r)
 variants={};q=p[:-1];variants['missing']=raised(lambda:run.assert_cohort(q,[origin],r));q=p+[p[0]];variants['duplicate']=raised(lambda:run.assert_cohort(q,[origin],r));q=copy.deepcopy(p);q[-1]['reference']=999;variants['changed_reference']=raised(lambda:run.assert_cohort(q,[origin],r));assert all(variants.values())
 return {'complete_passes':True,'refusals':variants}

# Deterministic substitutes solely for exercising the whole reference workflow.
class DummyModel:pass
class DummyAdapters:
 def __enter__(self):
  self.old=(models.load_chronos,models.load_mitra,models.chronos_predict,models.mitra_predict,run.free_gpu)
  models.load_chronos=lambda *a:DummyModel();models.load_mitra=lambda *a:DummyModel();models.chronos_predict=self.chronos;models.mitra_predict=self.mitra;run.free_gpu=lambda:None
  return self
 def __exit__(self,*args):models.load_chronos,models.load_mitra,models.chronos_predict,models.mitra_predict,run.free_gpu=self.old
 @staticmethod
 def chronos(model,history,h):
  m=float(history[-1]);return np.array([[max(0,m-2),m,m+2] for _ in range(h)])
 @staticmethod
 def mitra(model,X,y,q):
  # A deterministic software fixture, deliberately not a substitute scientific model.
  return np.full(len(np.atleast_2d(q)),float(np.mean(y)) + (0.001 if np.asarray(X).shape[1]>13 else 0))

@probe('08_all_stages_synthetic_integration_and_real_Ridge')
def p08():
 global FULL_ROOT
 FULL_ROOT=setup('synthetic_full_run',rows());out=FULL_ROOT/'results'
 import torch
 oldcuda=(torch.cuda.is_available,torch.cuda.reset_peak_memory_stats,torch.cuda.max_memory_allocated)
 oldversion=importlib.metadata.version
 def version(n):
  if n in ('chronos-forecasting','transformers'):return 'NOT-INSTALLED-REVIEW-DOUBLE'
  return oldversion(n)
 torch.cuda.is_available=lambda:True;torch.cuda.reset_peak_memory_stats=lambda:None;torch.cuda.max_memory_allocated=lambda:0
 importlib.metadata.version=version
 try:
  with DummyAdapters(),contextlib.redirect_stdout(io.StringIO()) as logs:
   for s in run.STAGES:
    if s=='reload':
     # Execute reload in a genuinely separate OS process; its own harness declares doubles.
     result=subprocess.run([sys.executable,str(BASE/'reload_fixture.py'),str(FULL_ROOT)],capture_output=True,text=True,timeout=40)
     if result.returncode:raise RuntimeError(result.stderr+'\n'+result.stdout)
     print(result.stdout)
    else:
     sys.argv=['dengue_runtime.py','--root',str(FULL_ROOT),'--stage',s];run.main()
  (OUT/'synthetic_stage_log.txt').write_text(logs.getvalue())
 finally:
  torch.cuda.is_available,torch.cuda.reset_peak_memory_stats,torch.cuda.max_memory_allocated=oldcuda;importlib.metadata.version=oldversion
 predictions=run.read(out/'test_predictions.json');assert len(predictions)==624
 future=run.read(out/'future_predictions.json');assert len(future)==24 and all(p['reference'] is None for p in future)
 return {'scope':'All stage orchestration with both model families replaced by deterministic doubles, GPU gate bypassed; CPU Ridge is real. Environment versions for absent model packages marked as doubles.','origins':26,'systems':6,'test_pairs_per_system':104,'test_rows':len(predictions),'future_rows':len(future),'future_target_keys':sorted({p['target_key'] for p in future}),'reload':run.read(out/'verification.json'),'root':str(FULL_ROOT)}

@probe('09_learner_table_hides_all_future_forecasts')
def p09():
 a=ast.parse((BASE/'bootstrap.py').read_text());f=next(n for n in a.body if isinstance(n,ast.FunctionDef) and n.name=='table')
 from IPython.display import Markdown,FileLink
 shown=[];ns={'ROOT':FULL_ROOT,'csv':csv,'Markdown':Markdown,'FileLink':FileLink,'display':lambda x:shown.append(x)}
 exec(compile(ast.Module(body=[f],type_ignores=[]),'exact_table_helper','exec'),ns)
 with contextlib.redirect_stdout(io.StringIO()) as log:ns['table']('future_predictions.csv')
 text=shown[0].data;(OUT/'future_table_visible.md').write_text(text)
 header=text.splitlines()[0]
 assert 'raw_prediction' not in header and '| prediction |' not in header
 assert 'chronos' not in text and 'mitra_' not in text
 return {'visible_columns':header,'total_rows':24,'visible_rows':12,'visible_systems':['persistence','seasonal','ridge'],'prediction_values_visible':False,'full_CSV_link_exists':True,'print_output':log.getvalue()}

@probe('10_delay_activity_isolation')
def p10():
 out=FULL_ROOT/'results';names=['test_predictions.json','predictions.csv','metrics.json','experiment_lock.json'];before={n:run.sha(out/n) for n in names}
 with DummyAdapters(),contextlib.redirect_stdout(io.StringIO()):run.activity(FULL_ROOT)
 after={n:run.sha(out/n) for n in names};assert before==after
 with (out/'validation_delay_activity.csv').open() as f:rows2=list(csv.DictReader(f))
 original=run.read(out/'validation_predictions.json')
 assert {(p['system'],int(p['origin']),int(p['horizon']),p['target_key']) for p in rows2}=={(p['system'],p['origin'],p['horizon'],p['target_key']) for p in original}
 assert all(int(p['cutoff'])==int(p['origin'])-2 for p in rows2)
 return {'canonical_files_unchanged':before,'identical_624_validation_keys':True,'all_cutoffs_shifted_two':True}

@probe('11_artifact_tamper_and_csv_refusals')
def p11():
 out=FULL_ROOT/'results';p=out/'artifact_future_ridge.json';old=p.read_bytes();p.write_bytes(old+b' ')
 try:
  result=subprocess.run([sys.executable,str(BASE/'reload_fixture.py'),str(FULL_ROOT),'--direct'],capture_output=True,text=True,timeout=30)
  err={'type':'subprocess_error','message':result.stderr} if result.returncode else None
 finally:p.write_bytes(old)
 assert err and 'Artifact hash' in err['message']
 p=out/'predictions.csv';old=p.read_bytes();p.write_bytes(old.replace(b'persistence',b'WRONG',1))
 try:err2=raised(lambda:run.report(FULL_ROOT))
 finally:p.write_bytes(old)
 assert err2 and 'CSV prediction' in err2['message']
 return {'artifact_refusal':err,'CSV_refusal':err2}

@probe('12_export_reconstruction_missing_dependencies')
def p12():
 root=OUT/'archive_only_reconstruction';root.mkdir(exist_ok=True);out=root/'results';out.mkdir(exist_ok=True)
 with zipfile.ZipFile(FULL_ROOT/'results/results.zip') as z:
  names=z.namelist();z.extractall(out)
  checks=json.loads(z.read('checksums.json'));assert all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in checks.items())
 # Supply the trusted implementation from the distributed notebook, as a user could do.
 for p in (BASE/'embedded').iterdir():
  if p.is_file():shutil.copyfile(p,root/p.name)
 shutil.copyfile(out/'dataset_audit.json',root/'dataset_audit.json')
 with DummyAdapters():err=raised(lambda:run.reload(root))
 assert err and 'data.json' in err['message']
 return {'archive_member_count':len(names),'all_listed_member_hashes_verified':True,'missing_external_dependencies':['data.json','run_config.json'],'first_failure_even_with_trusted_notebook_source_supplied':err,'same_workspace_separate_process_control_passed':run.read(FULL_ROOT/'results/verification.json')}

@probe('13_run_summary_missing_publication_vintage_caveat_and_area')
def p13():
 summary=run.read(FULL_ROOT/'results/run_summary.json');audit=run.read(FULL_ROOT/'dataset_audit.json')
 return {'summary_fields':list(summary),'BYOD_audit_fields':list(audit),'BYOD_area_name_recorded':any(k in audit for k in ('area','area_id','city','location')),'summary_explicit_final_vintage_caveat':any(x in json.dumps(summary).lower() for x in ('vintage','retrospective availability','reporting delay','pretraining')),'note':'Timing/alignment/prospective flags are false. Original notebook and conclusion_template contain richer caveats.'}

@probe('14_strict_source_data_numeric_controls')
def p14():
 import dengue_data as d
 r=rows()
 for x in r:x['covid']=int(x['year'] in (2020,2021))
 d.validate_qc(r)
 q=copy.deepcopy(r);q[0]['cases']=.5;e=raised(lambda:d.validate_qc(q));assert e
 q=copy.deepcopy(r);q[0]['temp']=500;e2=raised(lambda:d.validate_qc(q));assert e2
 return {'source_validator_rejects_fractional_cases':e,'source_validator_rejects_extreme_temp':e2,'contrast':'BYOD validator accepts both in probe06'}

save()

if len(RESULTS) != 14 or any(r['status'] != 'completed' for r in RESULTS):
    raise SystemExit('One or more review probes did not complete; inspect results.json')
