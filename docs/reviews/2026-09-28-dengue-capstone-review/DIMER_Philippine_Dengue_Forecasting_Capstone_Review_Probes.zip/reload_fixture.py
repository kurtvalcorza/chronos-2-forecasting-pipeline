"""Separate-process review harness. No actual pretrained model or GPU execution."""
import sys,pathlib,importlib.metadata
import numpy as np
BASE=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'embedded'))
import dengue_runtime as r
import dengue_models as m
import torch
class Dummy:pass
m.load_chronos=lambda *a:Dummy();m.load_mitra=lambda *a:Dummy()
def c(model,history,h):
 x=float(history[-1]);return np.array([[max(0,x-2),x,x+2] for _ in range(h)])
def t(model,X,y,q):return np.full(len(np.atleast_2d(q)),float(np.mean(y))+(0.001 if np.asarray(X).shape[1]>13 else 0))
m.chronos_predict=c;m.mitra_predict=t;r.free_gpu=lambda:None
torch.cuda.is_available=lambda:True;torch.cuda.reset_peak_memory_stats=lambda:None;torch.cuda.max_memory_allocated=lambda:0
root=sys.argv[1]
if '--direct' in sys.argv:r.reload(pathlib.Path(root))
else:
 sys.argv=['dengue_runtime.py','--root',root,'--stage','reload'];r.main()
