# Dengue forecasting PR20 — offline review probes

**SOFTWARE FIXTURES ONLY. No epidemiological findings or pretrained-model performance measurements are included.**

Review target: commit `209d8f5c8499949c8f78413d2cba3601e111c45b`, notebook Git blob `66309b6a5585a41d69f2e3e91915fd6c18c0ce03`.

## Contents and identity

`input_notebook.ipynb` is the exact uploaded/PR notebook, included for source-identity checks only. Do not execute its default download/model cells as part of these offline probes. `embedded/` contains the exact notebook-carried reference modules, lock, manifests and code licence. `bootstrap.py` contains the exact setup text; the probe only AST-extracts the table helper and does not run its installer. `probes.py` and `reload_fixture.py` are review harnesses, not changes to the repository.

The review ran fourteen groups of checks. A `completed` result means the check executed, including the expected reproduction of a defect, not that the target notebook passed. `probe_error` means the harness did not finish that check.

`observed/` contains the packaged-run results, the captured future-table Markdown, a synthetic stage log and one rendering made by the original plotting helper. **Every series and model prediction in these outputs is synthetic.** The main harness substitutes both pretrained-model adapters, bypasses the GPU gate, and marks absent upstream packages as review doubles. It does actually fit Ridge, serialize JSON numeric state, execute the original stage/receipt logic and launch a separate OS process for the reconstruction check. The separate process uses the same declared substitutes. None of this is Colab, GPU, real-model, clinical or population-health evidence.

## Reproduce

Use a fresh extraction directory and a CPU Python environment. The observed review environment used Python 3.13.5, NumPy 2.3.5, PyTorch 2.10.0+cpu, Matplotlib 3.10.8, IPython and nbformat 5.10.4. This differs from the target notebook's full pinned environment; the tests do not qualify that environment. The review package does not require AutoGluon, Transformers, Chronos, model weights or external network access once these ordinary dependencies are available.

Run:

```bash
python probes.py
```

The script writes `probe_outputs/` next to itself and reports 14 completed groups. Use a fresh directory for each reproduction; generated receipts include process IDs and run-specific paths, so hashes and PIDs legitimately differ. Read `probe_outputs/results.json` for semantic observations rather than comparing synthetic archive bytes across runs.

The bundled `observed/` evidence is kept separate and is not overwritten by reproduction. The harness creates a ZIP from its own synthetic outputs and extracts that trusted fixture only; it does not accept arbitrary user archives. Ordinary data acquisition, pretrained inference and notebook setup are not invoked.

## Important evidence limits

- All-zero BYOD refusal executes the real adapter preflight, before AutoGluon imports. It does not run a real Mitra model.
- The Chronos output-contract probe uses the actual adapter with a CPU tensor-returning model double.
- The complete workflow uses substituted pretrained adapters, not the actual image/forecasting neural networks.
- Original-workspace reconstruction passes under the substitutes; archive-only reconstruction fails because required original files are absent. This does not establish corrupted support arrays.
- No patient records, real QC case/weather data, pretrained weights, secrets or fonts are included.
- No repository edits or PR comments were made.

The only packaging changes to the review harness are a relative input-notebook path and an explicit nonzero exit if any probe failed to complete. The notebook-carried source is unchanged.
