"""Reduced offline probes for the DIMER multi-model forecasting notebook.

Reviewed commit: e13b36249cb3b9e4cd46993ccb581dbe2d6b94e0
Notebook blob: 8d65d164525e46e81649c581d4983812cfa67e41

The source excerpts below were transcribed from the GitHub connector's decoded
notebook cells. This is NOT an execution of the complete original notebook.
No model weights, pretrained inference, network request or repository mutation
is used. Generated forecast tables are controlled fixtures, not model results.
"""
from __future__ import annotations
import csv
import hashlib
import importlib.metadata
import io
import json
import platform
import shutil
import tempfile
import warnings
import zipfile
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

COMMIT = 'e13b36249cb3b9e4cd46993ccb581dbe2d6b94e0'
BLOB = '8d65d164525e46e81649c581d4983812cfa67e41'
VALIDATION_HORIZON = 24
TEST_HORIZON = 24
SEASON_LENGTH = 24
COMMON_MIN_CONTEXT = 32
COMMON_MAX_CONTEXT = 8192
COMMON_MAX_HORIZON = 1024
REQUIRED_COLUMNS = ['series_id', 'timestamp', 'target']

# Section 3.1: canonical generator and CSV parser.
def canonical_sample_bytes():
    n = 96
    timestamps = pd.date_range('2026-01-01', periods=n, freq='h')
    step = np.arange(n, dtype=float)
    parts = []
    for series_id, offset, slope, amplitude, phase in (
        ('A', 0.0, 0.18, 6.0, 0.0),
        ('B', 35.0, 0.12, 9.0, 5.0),
    ):
        target = 120.0 + offset + slope * step + amplitude * np.sin(2.0 * np.pi * (step + phase) / 24.0)
        parts.append(pd.DataFrame({'series_id': series_id, 'timestamp': timestamps, 'target': target}))
    frame = pd.concat(parts, ignore_index=True)
    return frame.to_csv(index=False, date_format='%Y-%m-%dT%H:%M:%S',
                        float_format='%.4f', lineterminator='\n').encode('utf-8')


def read_checked_csv(payload):
    rows = csv.reader(io.StringIO(payload.decode('utf-8-sig')))
    try:
        header = next(rows)
    except StopIteration as exc:
        raise ValueError('CSV is empty') from exc
    duplicates = sorted(name for name, count in Counter(header).items() if count > 1)
    if duplicates:
        raise ValueError(f'Duplicate CSV header(s) are ambiguous: {duplicates}')
    return pd.read_csv(io.BytesIO(payload))

# Section 3.2, transcribed validation function; no model calls.
def validate_panel(frame):
    missing = [c for c in REQUIRED_COLUMNS if c not in frame.columns]
    if missing:
        raise ValueError(f'Missing required columns: {missing}')
    work = frame[REQUIRED_COLUMNS].copy()
    if work['series_id'].isna().any():
        raise ValueError('series_id contains null values')
    work['series_id'] = work['series_id'].astype(str)
    if (work['series_id'].str.len() == 0).any():
        raise ValueError('series_id contains empty values')
    work['timestamp'] = pd.to_datetime(work['timestamp'], errors='raise')
    work['target'] = pd.to_numeric(work['target'], errors='raise')
    if not np.isfinite(work['target'].to_numpy(dtype=float)).all():
        raise ValueError('target contains missing or non-finite values')
    if work.duplicated(['series_id', 'timestamp']).any():
        raise ValueError('Duplicate (series_id, timestamp) observations are not allowed')
    work = work.sort_values(['series_id', 'timestamp'], kind='mergesort').reset_index(drop=True)
    ids = list(work['series_id'].drop_duplicates())
    if not ids:
        raise ValueError('No target series found')
    if len(ids) > 16:
        raise ValueError('BYOD is limited to 16 series in this notebook')
    time_grids = []
    for sid in ids:
        block = work[work['series_id'] == sid]
        ts = pd.DatetimeIndex(block['timestamp'])
        if not ts.is_monotonic_increasing or ts.has_duplicates:
            raise ValueError(f'{sid}: timestamps must be strictly increasing and unique')
        if len(ts) < 2:
            raise ValueError(f'{sid}: at least two timestamps are required')
        deltas = pd.Series(ts).diff().dropna()
        if deltas.nunique() != 1:
            raise ValueError(f'{sid}: irregular or gappy frequency is not supported')
        time_grids.append(ts)
    reference = time_grids[0]
    for sid, grid in zip(ids[1:], time_grids[1:]):
        if not grid.equals(reference):
            raise ValueError(f'{sid}: all series must use exactly the same timestamp grid in this comparative notebook')
    delta = reference[1] - reference[0]
    try:
        freq_alias = pd.tseries.frequencies.to_offset(delta).freqstr
    except Exception as exc:
        raise ValueError(f'Could not represent fixed-width frequency {delta}') from exc
    n_steps = len(reference)
    required_tail = VALIDATION_HORIZON + TEST_HORIZON
    if n_steps - required_tail < COMMON_MIN_CONTEXT:
        raise ValueError(f'Need at least {COMMON_MIN_CONTEXT + required_tail} observations per series '
                         f'({COMMON_MIN_CONTEXT} context + {required_tail} holdout); got {n_steps}')
    if n_steps - TEST_HORIZON > COMMON_MAX_CONTEXT:
        print(f'NOTE: test history has {n_steps - TEST_HORIZON} observations; '
              f'the common comparison will keep only the most recent {COMMON_MAX_CONTEXT}.')
    return {'frame': work, 'series_ids': ids, 'timestamps': reference,
            'frequency': delta, 'frequency_alias': freq_alias, 'n_steps': n_steps,
            'n_series': len(ids), 'target_min': float(work['target'].min()),
            'target_max': float(work['target'].max())}

# Section 5.1: common split and scoring logic.
def tail_context(block, end_index, max_context=COMMON_MAX_CONTEXT):
    return block.iloc[max(0, end_index - max_context):end_index].copy()


def split_stage(frame, stage):
    ids = panel['series_ids']
    pieces_history, pieces_truth = [], []
    n = panel['n_steps']
    if stage == 'validation':
        truth_start, truth_horizon = n - TEST_HORIZON - VALIDATION_HORIZON, VALIDATION_HORIZON
    elif stage == 'test':
        truth_start, truth_horizon = n - TEST_HORIZON, TEST_HORIZON
    elif stage == 'future':
        truth_start, truth_horizon = n, TEST_HORIZON
    else:
        raise ValueError(stage)
    for sid in ids:
        block = frame[frame['series_id'] == sid].sort_values('timestamp').reset_index(drop=True)
        hist = tail_context(block, truth_start)
        if len(hist) < COMMON_MIN_CONTEXT:
            raise ValueError(f'{stage}/{sid}: context shorter than {COMMON_MIN_CONTEXT}')
        pieces_history.append(hist)
        if stage != 'future':
            pieces_truth.append(block.iloc[truth_start:truth_start+truth_horizon].copy())
    history = pd.concat(pieces_history, ignore_index=True)
    truth = pd.concat(pieces_truth, ignore_index=True) if pieces_truth else None
    return history, truth, truth_horizon


def mae(y, p):
    y, p = np.asarray(y, float), np.asarray(p, float)
    return float(np.mean(np.abs(y-p)))


def rmse(y, p):
    y, p = np.asarray(y, float), np.asarray(p, float)
    return float(np.sqrt(np.mean((y-p)**2)))


def pinball_loss(y, qhat, q):
    error = np.asarray(y, float) - np.asarray(qhat, float)
    return float(np.mean(np.maximum(q*error, (q-1.0)*error)))


def baseline_forecast(history, truth, kind, season_length=SEASON_LENGTH):
    rows = []
    for sid in panel['series_ids']:
        h = history[history['series_id'] == sid].sort_values('timestamp')
        t = truth[truth['series_id'] == sid].sort_values('timestamp')
        values = h['target'].to_numpy(dtype=float)
        if kind == 'last_value':
            pred = np.repeat(values[-1], len(t))
        elif kind == 'seasonal_naive':
            if len(values) < season_length:
                raise ValueError(f'{sid}: seasonal baseline needs at least {season_length} historical observations')
            pred = np.asarray([values[-season_length + step % season_length] for step in range(len(t))], dtype=float)
        else:
            raise ValueError(kind)
        for step, ((_, truth_row), forecast) in enumerate(zip(t.iterrows(), pred), start=1):
            rows.append({'model': kind, 'series_id': sid, 'timestamp': truth_row['timestamp'],
                         'step': step, 'prediction': float(forecast), 'q0.1': float(forecast),
                         'q0.5': float(forecast), 'q0.9': float(forecast)})
    return pd.DataFrame(rows)


def evaluate_forecasts(forecasts, truth, seasonal_baseline):
    truth_key = truth[['series_id', 'timestamp', 'target']].rename(columns={'target': 'truth'})
    duplicated = forecasts.duplicated(['model', 'series_id', 'timestamp'])
    if duplicated.any():
        raise ValueError(f'Duplicate forecast rows per model/series/timestamp: {int(duplicated.sum())}')
    merged = forecasts.merge(truth_key, on=['series_id', 'timestamp'], how='left', validate='many_to_one')
    if merged['truth'].isna().any():
        raise ValueError('Forecast rows do not align exactly to held-out truth')
    seasonal = seasonal_baseline.merge(truth_key, on=['series_id', 'timestamp'], how='left', validate='one_to_one')
    seasonal_mae_by_series = {sid: mae(b['truth'], b['prediction']) for sid, b in seasonal.groupby('series_id')}
    per_series = []
    for (model, sid), block in merged.groupby(['model', 'series_id'], sort=False):
        model_mae = mae(block['truth'], block['prediction'])
        seasonal_mae = seasonal_mae_by_series[sid]
        per_series.append({
            'model': model, 'series_id': sid, 'mae': model_mae,
            'rmse': rmse(block['truth'], block['prediction']), 'seasonal_naive_mae': seasonal_mae,
            'mae_skill_vs_seasonal': 1.0-model_mae/seasonal_mae if seasonal_mae > 0 else None,
            'pinball_q0.1': pinball_loss(block['truth'], block['q0.1'], .1),
            'pinball_q0.5': pinball_loss(block['truth'], block['q0.5'], .5),
            'pinball_q0.9': pinball_loss(block['truth'], block['q0.9'], .9),
            'q10_q90_coverage': float(np.mean((block['truth'].to_numpy() >= block['q0.1'].to_numpy()) &
                                             (block['truth'].to_numpy() <= block['q0.9'].to_numpy()))),
            'mean_interval_width': float(np.mean(block['q0.9'].to_numpy()-block['q0.1'].to_numpy())),
        })
    per_series = pd.DataFrame(per_series)
    aggregate_rows = []
    for model, block in merged.groupby('model', sort=False):
        ps = per_series[per_series['model'] == model]
        aggregate_rows.append({
            'model': model, 'pooled_mae': mae(block['truth'], block['prediction']),
            'pooled_rmse': rmse(block['truth'], block['prediction']),
            'macro_mae': float(ps['mae'].mean()), 'macro_rmse': float(ps['rmse'].mean()),
            'macro_mae_skill_vs_seasonal': float(ps['mae_skill_vs_seasonal'].mean()),
            'q10_q90_coverage': float(np.mean((block['truth'].to_numpy() >= block['q0.1'].to_numpy()) &
                                             (block['truth'].to_numpy() <= block['q0.9'].to_numpy()))),
            'mean_interval_width': float(np.mean(block['q0.9'].to_numpy()-block['q0.1'].to_numpy())),
            'pinball_q0.1': pinball_loss(block['truth'], block['q0.1'], .1),
            'pinball_q0.5': pinball_loss(block['truth'], block['q0.5'], .5),
            'pinball_q0.9': pinball_loss(block['truth'], block['q0.9'], .9),
        })
    return merged, per_series, pd.DataFrame(aggregate_rows)


def expect_exception(fn):
    try:
        fn()
    except Exception as exc:
        return {'type': type(exc).__name__, 'message': str(exc)}
    raise AssertionError('Expected an exception, but the probe was accepted')


def fixture_forecast(truth, name='fixture', error=0.0):
    f = truth[['series_id','timestamp']].copy()
    f['model'] = name
    f['prediction'] = truth['target'].to_numpy() + error
    f['q0.5'] = f['prediction']
    f['q0.1'] = f['prediction'] - 1
    f['q0.9'] = f['prediction'] + 1
    f['forecast_origin'] = truth['timestamp'].min() - pd.Timedelta(hours=1)
    f['step'] = f.groupby('series_id', sort=False).cumcount()+1
    return f


def main():
    global panel
    out = Path(__file__).resolve().parent
    results = []
    def record(name, outcome, details):
        results.append({'probe': name, 'outcome': outcome, 'details': details})

    payload = canonical_sample_bytes()
    digest = hashlib.sha256(payload).hexdigest()
    assert digest == '6f12f1475411aaab13a2de860ba50f008bd7185a9266f99147c244db4a5de8b3'
    panel = validate_panel(read_checked_csv(payload))
    f = panel['frame']
    vh, vt, _ = split_stage(f, 'validation')
    th, tt, _ = split_stage(f, 'test')
    fh, _, _ = split_stage(f, 'future')
    for hist, truth in [(vh,vt),(th,tt)]:
        for sid in panel['series_ids']:
            assert hist.loc[hist.series_id == sid,'timestamp'].max() < truth.loc[truth.series_id == sid,'timestamp'].min()
    seasonal = baseline_forecast(vh, vt, 'seasonal_naive')
    last = baseline_forecast(vh, vt, 'last_value')
    _, ps, ag = evaluate_forecasts(pd.concat([seasonal,last]), vt, seasonal)
    assert np.isclose(ag.set_index('model').loc['seasonal_naive','macro_mae'],3.6)
    record('P01_canonical_sample_splits_baselines','positive control passed',
           {'sha256':digest, 'rows':len(f), 'context_steps':[len(x)//2 for x in [vh,th,fh]],
            'aggregate':ag.to_dict('records')})

    # Section 4.1 uses all observations, rather than restricting development views.
    fig, ax = plt.subplots(figsize=(12,5))
    exposed = {}
    for sid in panel['series_ids']:
        block=f[f.series_id==sid]
        line,=ax.plot(block.timestamp,block.target,label=sid)
        times=pd.to_datetime(line.get_xdata())
        exposed[sid] = int((times >= panel['timestamps'][72]).sum())
    ax.axvline(panel['timestamps'][48],linestyle='--',label='validation starts')
    ax.axvline(panel['timestamps'][72],linestyle='--',label='test starts')
    ax.set_title('Time-series panel');ax.set_xlabel('Timestamp');ax.set_ylabel('Target');ax.legend()
    fig.tight_layout();fig.savefig(out/'reproduced_pre_model_eda.png',dpi=120);plt.close(fig)
    assert exposed == {'A':24,'B':24}
    record('P02_pre_model_test_target_exposure','reproduced',{'test_target_points_plotted':exposed})

    # Parser controls from Sections 3.1/3.2, same schema as the default.
    record('P03_input_rejection_controls','positive controls passed',{
        'missing_target':expect_exception(lambda: validate_panel(f.drop(columns='target'))),
        'duplicate_timestamp':expect_exception(lambda: validate_panel(pd.concat([f,f.head(1)]))),
        'gappy':expect_exception(lambda: validate_panel(f.drop(index=4))),
        'infinite_target':expect_exception(lambda: validate_panel(f.assign(target=np.where(f.index==0,np.inf,f.target)))),
    })

    # Controlled output tables substitute ONLY for pretrained inference.
    for ids in [('A','B'),('101','202')]:
        raw=read_checked_csv(payload)
        raw['series_id']=raw['series_id'].map({'A':ids[0],'B':ids[1]})
        raw=read_checked_csv(raw.to_csv(index=False).encode())
        panel=validate_panel(raw)
        hist,truth,_=split_stage(panel['frame'],'validation')
        sb=baseline_forecast(hist,truth,'seasonal_naive')
        preds=fixture_forecast(truth)
        # Same CSV read as run_model in Section 7.1.
        reloaded=pd.read_csv(io.StringIO(preds.to_csv(index=False)),parse_dates=['timestamp','forecast_origin'])
        combined=pd.concat([reloaded,sb],ignore_index=True)
        if ids[0]=='A':
            evaluate_forecasts(combined,truth,sb)
        else:
            error=expect_exception(lambda: evaluate_forecasts(combined,truth,sb))
            record('P04_numeric_series_id_roundtrip','reproduced',{
                'input_accepted':True,'ids_after_validation':panel['series_ids'],
                'forecast_reload_dtype':str(reloaded.series_id.dtype),
                'error':error,'alphabetic_id_positive_control':'passed',
                'pretrained_models_executed':False})

    panel=validate_panel(read_checked_csv(payload))
    hist,truth,_=split_stage(panel['frame'],'validation')
    seasonal=baseline_forecast(hist,truth,'seasonal_naive')
    pred=fixture_forecast(truth)
    pred.loc[pred.index[-1],['prediction','q0.1','q0.5','q0.9']] += 100
    full=evaluate_forecasts(pred,truth,seasonal)[2].iloc[0]
    truncated=pred.iloc[:-1].copy()
    partial=evaluate_forecasts(truncated,truth,seasonal)[2].iloc[0]
    assert full['pooled_mae']>2 and partial['pooled_mae']==0
    only_a=fixture_forecast(truth[truth.series_id=='A'])
    missing_series=evaluate_forecasts(only_a,truth,seasonal)[2].iloc[0]
    record('P05_incomplete_forecast_grid','reproduced',{
        'expected_rows':len(truth),'rows_after_drop':len(truncated),
        'full_pooled_mae':float(full.pooled_mae),'truncated_pooled_mae':float(partial.pooled_mae),
        'whole_series_omitted_still_accepted':True,'one_series_pooled_mae':float(missing_series.pooled_mae),
        'duplicate_row_rejected':expect_exception(lambda: evaluate_forecasts(pd.concat([pred,pred.head(1)]),truth,seasonal))})

    crossed=fixture_forecast(truth)
    crossed['q0.1']=crossed['prediction']+1
    crossed['q0.9']=crossed['prediction']-1
    cross_ag=evaluate_forecasts(crossed,truth,seasonal)[2].iloc[0]
    assert cross_ag.mean_interval_width == -2
    missing=fixture_forecast(truth);missing['q0.1']=np.nan
    nan_ag=evaluate_forecasts(missing,truth,seasonal)[2].iloc[0]
    record('P06_invalid_forecast_quantiles','reproduced',{
        'crossed_quantiles_accepted':True,'mean_interval_width':float(cross_ag.mean_interval_width),
        'nonfinite_lower_quantiles_accepted':True,'coverage_with_missing_lower':float(nan_ag.q10_q90_coverage),
        'runners_or_models_returned_these_in_real_run':False})

    # Section 9.1 freeze assertions copied into a controlled state fixture.
    with tempfile.TemporaryDirectory() as td:
        root=Path(td);runners=root/'runners';runners.mkdir()
        for n in ['tirex','chronos']:(runners/f'{n}_runner.py').write_text('# inert probe runner\n')
        def source_sha(n):return hashlib.sha256((runners/f'{n}_runner.py').read_bytes()).hexdigest()
        specs={n:{'revision': n+'-fixture-revision'} for n in ['tirex','chronos']}
        selected=['tirex','chronos'];qs=[.1,.5,.9]
        frozen={'sample_sha256':digest,'execution_tier':'STANDARD','selected_models':selected,
                'quantiles':qs,'test_horizon':24,'season_length':24,
                'common_max_context':8192,'validation_horizon':24,
                'models':{n:{'revision':specs[n]['revision'],'runner_sha256':source_sha(n)} for n in selected}}
        def freeze_checks():
            assert frozen['sample_sha256']==digest
            assert frozen['execution_tier']=='STANDARD'
            assert frozen['selected_models']==selected
            assert frozen['quantiles']==list(qs)
            assert frozen['test_horizon']==24
            assert frozen['season_length']==24
            for n in selected:
                assert frozen['models'][n]['revision']==specs[n]['revision']
                assert frozen['models'][n]['runner_sha256']==source_sha(n)
        request=root/'test_history.csv';th.to_csv(request,index=False)
        old_hash=hashlib.sha256(request.read_bytes()).hexdigest()
        changed=pd.read_csv(request);changed.loc[0,'target'] += 1000;changed.to_csv(request,index=False)
        new_hash=hashlib.sha256(request.read_bytes()).hexdigest()
        freeze_checks()
        assert old_hash != new_hash
        record('P07_changed_execution_input_not_checked_by_freeze','reproduced',{
            'request_sha_before':old_hash,'request_sha_after':new_hash,
            'all_visible_freeze_assertions_passed':True,'models_executed':False})

        # Section 1 creates shared directories with exist_ok=True; 13 archives ALL.
        output=root/'outputs';(output/'test').mkdir(parents=True);(output/'figures').mkdir()
        (output/'activities').mkdir()
        (output/'test'/'toto.csv').write_text('model,series_id\nToto 2.0,old_weather_run\n')
        (output/'figures'/'validation_toto_quantiles.png').write_bytes(b'old plot placeholder')
        (output/'activities'/'seasonal_period_comparison.csv').write_text('old activity\n')
        (output/'test'/'chronos.csv').write_text('model,series_id\nChronos-2,A\n')
        (output/'test'/'tirex.csv').write_text('model,series_id\nTiRex-2,A\n')
        (output/'workshop_summary.json').write_text(json.dumps({'tier':'STANDARD','models':['TiRex-2','Chronos-2']}))
        bundle=shutil.make_archive(str(output.resolve())+'_DIMER_TimeSeries_FM_Workshop_Report','zip',root_dir=output.resolve())
        with zipfile.ZipFile(bundle) as z: names=z.namelist()
        stale=[n for n in names if 'toto' in n or n.endswith('seasonal_period_comparison.csv')]
        assert len(stale)==3
        record('P08_shared_output_directory_archive','reproduced',{
            'current_tier':'STANDARD','older_artifacts_in_current_zip':stale,
            'fixture_only_no_models_executed':True})

    # Arithmetic explanation: equal lengths make pooled MAE == macro MAE.
    scaled=fixture_forecast(truth)
    scaled['prediction'] += np.where(scaled.series_id=='A',1.0,100.0)
    scaled['q0.5']=scaled.prediction;scaled['q0.1']=scaled.prediction-1;scaled['q0.9']=scaled.prediction+1
    ag=evaluate_forecasts(scaled,truth,seasonal)[2].iloc[0]
    assert np.isclose(ag.pooled_mae,50.5) and np.isclose(ag.macro_mae,50.5)
    record('P09_macro_mae_not_scale_normalized','arithmetic verified',{
        'per_series_absolute_errors':[1,100],'pooled_mae':float(ag.pooled_mae),'macro_mae':float(ag.macro_mae)})

    # Ready-made optional activity: only period changes.
    activity=[]
    for period in (12,24):
        p=baseline_forecast(hist,truth,'seasonal_naive',season_length=period)
        paired=p.merge(truth[['series_id','timestamp','target']],on=['series_id','timestamp'],validate='one_to_one')
        assert len(paired)==len(truth)
        for sid,b in paired.groupby('series_id'):
            activity.append({'period':period,'series_id':sid,'mae':mae(b.target,b.prediction)})
    pd.DataFrame(activity).to_csv(out/'seasonal_activity_probe.csv',index=False)
    record('P10_seasonal_activity','positive control passed',{'scores':activity,'validation_rows_in_each_condition':len(truth)})

    future_dates=pd.date_range(fh.timestamp.max()+panel['frequency'],periods=24,freq=panel['frequency'])
    record('P11_future_relative_to_dataset','date arithmetic verified',{
        'synthetic_forecast_first':str(future_dates[0]),'synthetic_forecast_last':str(future_dates[-1]),
        'weather_forecast_day':'2026-09-09','review_date':'2026-09-27',
        'both_forecast_windows_precede_review_date':bool(future_dates[-1]<pd.Timestamp('2026-09-27'))})

    result={'reviewed_commit':COMMIT,'reviewed_notebook_blob':BLOB,
            'scope':'Transcribed source-boundary probes, synthetic forecast fixtures, and arithmetic; NOT a full notebook or model execution.',
            'environment':{'python':platform.python_version(),
                           **{n:importlib.metadata.version(n) for n in ['numpy','pandas','matplotlib']}},
            'probe_count':len(results),'results':results}
    (out/'probe_results.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps(result,indent=2,allow_nan=False))

if __name__=='__main__':
    main()
