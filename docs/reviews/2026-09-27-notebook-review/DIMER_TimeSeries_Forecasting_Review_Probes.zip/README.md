# Offline review probes — multi-model forecasting notebook

Reviewed repository commit: `e13b36249cb3b9e4cd46993ccb581dbe2d6b94e0`.
Reviewed notebook Git blob: `8d65d164525e46e81649c581d4983812cfa67e41`.

These are transcribed source-boundary probes and controlled fixtures, not the
complete original notebook. No model weights or pretrained inference are used.
A reproduced invalid-output case does not imply that a real upstream run
returned that invalid output. No repository is modified.

## Reproduce

Use a disposable Python environment with NumPy, pandas and Matplotlib:

```sh
python review_probes.py
```

The recorded review used Python 3.13.5, NumPy 2.3.5, pandas 2.2.3 and
Matplotlib 3.10.8. The script requires no internet access once dependencies are
installed. It writes its JSON receipt, reproduced EDA plot and activity CSV
beside the script. The original model stacks are not installed.

`reproduced_pre_model_eda.png` was rendered locally using the source plot
pattern and the digest-matched synthetic sample. It is NOT a screenshot of
the original Colab execution. `seasonal_activity_probe.csv` contains the
locally recomputed baseline-only activity values.

Read the review report for findings, limitations, and acceptance checks.
